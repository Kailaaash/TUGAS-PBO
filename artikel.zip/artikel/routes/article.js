const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Middleware to check if user is logged in
const isLoggedIn = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/auth/login');
    }
};

// Apply isLoggedIn middleware to all routes
router.use(isLoggedIn);

// READ / Menampilkan semua data articles
router.get('/', (req, res) => {
    const query = `SELECT * FROM articles`;
    db.query(query, (err, results) => {
        if (err) {
            console.error(err);
            return res.render('articles/articles', { error: 'Error fetching data.', articles: [] });
        }
        res.render('articles/articles', { articles: results, user: req.session.user });
    });
});

// CREATE / INSERT data
router.post('/add', (req, res) => {
    const { title, content } = req.body;
    const query = `INSERT INTO articles (title, content) VALUES (?, ?)`;
    db.query(query, [title, content], (err, result) => {
        if (err) {
            console.error(err);
            return res.render('articles/articles', { error: 'Error adding data.', articles: [], user: req.session.user });
        }
        res.redirect('/article');
    });
});

// Untuk akses halaman edit
router.get('/edit/:id', (req, res) => {
    const query = `SELECT * FROM articles WHERE id = ?`;
    db.query(query, [req.params.id], (err, result) => {
        if (err) {
            console.error(err);
            return res.redirect('/edit');
        }
        res.render('articles/edit', { articles: result[0], user: req.session.user });
    });
});

// UPDATE / Memperbarui data articles
router.post('/update/:id', (req, res) => {
    const { title, content } = req.body;
    const query = `UPDATE articles SET title = ?, content = ? WHERE id = ?`;
    
    db.query(query, [title, content, req.params.id], (err, result) => {
        if (err) {
            console.error("Kesalahan saat update:", err);
            // Menampilkan halaman error atau redirect dengan pesan kesalahan
            return res.render('articles/edit', { articles: req.body, error: 'Error updating data', user: req.session.user });
        }
        res.redirect('/article');
    });
});

// DELETE / Menghapus data articles
router.get('/delete/:id', (req, res) => {
    const query = `DELETE FROM articles WHERE id = ?`;
    db.query(query, [req.params.id], (err, result) => {
        if (err) {
            console.error(err);
            return res.redirect('/article');
        }
        res.redirect('/article');
    });
});

module.exports = router;