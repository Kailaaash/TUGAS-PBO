const express = require('express');
const router = express.Router();
const db = require('../config/db');

// READ / Menampilkan semua data articles
router.get('/', (req, res) => {
    const query = `SELECT * FROM articles`;
    db.query(query, (err, results) => {
        if (err) {
            console.error(err);
            return res.render('home', { error: 'Error fetching data.', articles: [] });
        }
        res.render('home', { articles: results, user: req.session.user });
    });
});

// READ / Menampilkan detail data article berdasarkan id
router.get('/detail/:id', (req, res) => {
    const query = `SELECT * FROM articles WHERE id = ?`;
    db.query(query, [req.params.id], (err, results) => {
        if (err) {
            console.error(err);
            return res.render('articleDetail', { error: 'Error fetching data.', article: null });
        }
        if (results.length === 0) {
            return res.render('articleDetail', { error: 'Article not found.', article: null });
        }
        res.render('articleDetail', { article: results[0], user: req.session.user });
    });
});

module.exports = router;