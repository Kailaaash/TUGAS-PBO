const express = require('express');
const router = express.Router();
const db = require('../config/db');
const bcrypt = require('bcrypt');

// Middleware to check if user is logged in
const isLoggedIn = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/auth/login');
    }
};

// Apply isLoggedIn middleware to all routes
router.use(isLoggedIn);

// READ / Menampilkan semua data users
router.get('/', (req, res) => {
    const query = `SELECT * FROM user`;
    db.query(query, (err, results) => {
        if (err) {
            console.error(err);
            return res.render('user/index', { error: 'Error fetching data.', users: [] });
        }
        res.render('user/index', { users: results, user: req.session.user });
    });
});

// CREATE / INSERT data
router.post('/add', (req, res) => {
    const { username, email, password } = req.body;
    const saltRounds = 10;
    
    bcrypt.hash(password, saltRounds, (err, hashedPassword) => {
        if (err) {
            console.error(err);
            return res.render('user/index', { error: 'Error hashing password.', users: [], user: req.session.user });
        }
        
        const query = `INSERT INTO user (username, email, password) VALUES (?, ?, ?)`;
        db.query(query, [username, email, hashedPassword], (err, result) => {
            if (err) {
                console.error(err);
                return res.render('user/index', { error: 'Error adding data.', users: [], user: req.session.user });
            }
            res.redirect('/kelola-akun');
        });
    });
});

// Untuk akses halaman edit
router.get('/edit/:id', (req, res) => {
    const query = `SELECT * FROM user WHERE id = ?`;
    db.query(query, [req.params.id], (err, result) => {
        if (err) {
            console.error(err);
            return res.redirect('/kelola-akun');
        }
        if (result.length === 0) {
            return res.redirect('/kelola-akun');
        }
        res.render('user/edit', { users: result[0], user: req.session.user });
    });
});

// UPDATE / Memperbarui data user
router.post('/update/:id', (req, res) => {
    const { username, email, password } = req.body;
    const query = `UPDATE user SET username = ?, email = ?, password = ? WHERE id = ?`;
    
    db.query(query, [username, email, password, req.params.id], (err, result) => {
        if (err) {
            console.error("Kesalahan saat update:", err);
            return res.render('user/edit', { users: req.body, error: 'Error updating data', user: req.session.user });
        }
        res.redirect('/kelola-akun');
    });
});

// DELETE / Menghapus data user
router.get('/delete/:id', (req, res) => {
    const query = `DELETE FROM user WHERE id = ?`;
    db.query(query, [req.params.id], (err, result) => {
        if (err) {
            console.error(err);
            return res.redirect('/kelola-akun');
        }
        res.redirect('/kelola-akun');
    });
});

module.exports = router;